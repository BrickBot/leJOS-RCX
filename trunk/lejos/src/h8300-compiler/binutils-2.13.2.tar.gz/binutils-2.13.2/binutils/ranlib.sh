#!/bin/sh
# A simple ranlib script, to use less disk space than a ranlib program.
ar s $1
