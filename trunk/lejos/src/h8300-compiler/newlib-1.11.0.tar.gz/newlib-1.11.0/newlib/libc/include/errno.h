#ifndef __ERRNO_H__
#define __ERRNO_H__

typedef int error_t;

#include <sys/errno.h>

#endif /* !__ERRNO_H__ */
